from setuptools import setup

setup(name='Selen_utils',
      version='0.0',
      description='Selenium_template_utils',
      packages=['Selen_utils'],#, 'selenium-wire', 'selenium', 'fake_useragent', 'loguru', 'requests', 'pandas', 'dataclasses'],
      author_email='alisbivalka@gmail.com',
      zip_safe=False)
